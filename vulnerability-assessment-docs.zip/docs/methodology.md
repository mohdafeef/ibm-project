# 🛡️ Vulnerability Assessment Methodology

![Security](https://img.shields.io/badge/Security-Assessment-blue)
![Scope](https://img.shields.io/badge/Scope-Web%20Application-informational)
![Status](https://img.shields.io/badge/Status-Completed-success)

This document outlines the step-by-step methodology used to perform the vulnerability assessment on the target web application.

---

## 🔍 1. Reconnaissance

**Objective**: Gather intelligence on the target system.

| Technique              | Tool / Method                                           |
|------------------------|---------------------------------------------------------|
| DNS Enumeration        | [`nslookup`](https://ss64.com/nt/nslookup.html), `dig` |
| WHOIS Lookup           | [whois.domaintools.com](https://whois.domaintools.com) |
| Subdomain Discovery    | [`Sublist3r`](https://github.com/aboul3la/Sublist3r), `Assetfinder` |
| Tech Fingerprinting    | [`WhatWeb`](https://github.com/urbanadventurer/WhatWeb), [Wappalyzer](https://www.wappalyzer.com/) |

---

## 🧭 2. Scanning and Enumeration

| Task                  | Tools |
|------------------------|----------------------------|
| Port Scanning          | [`Nmap`](https://nmap.org/) |
| Banner Grabbing        | Netcat, Telnet              |
| Directory Brute-force  | [`Gobuster`](https://github.com/OJ/gobuster), `Dirb` |

---

## 🧪 3. Vulnerability Scanning

| Task                  | Tools |
|------------------------|----------------------------|
| Web App Scanning       | [`OWASP ZAP`](https://owasp.org/www-project-zap/), `Nikto` |
| Network Scanning       | `OpenVAS`, `Nessus`        |
| Auth/Session Testing   | [`Burp Suite`](https://portswigger.net/burp) |

---

## 🧠 4. Manual Testing & Exploitation

Tested for:
- SQL Injection using [`sqlmap`](https://sqlmap.org)
- XSS via `XSS Hunter`
- IDOR, CSRF, Session Hijacking
- Broken Authentication

---

## 🗂 5. Documentation & Reporting

| Resource          | Tool Used |
|-------------------|-----------|
| Final Report      | LibreOffice, MS Word |
| Screenshots       | Shutter, Snipping Tool |
| Risk Ratings      | [CVSS Calculator](https://www.first.org/cvss/calculator/3.1) |

---

## 🔁 6. Retesting (If Applicable)

Re-validation of previously identified issues to confirm patch effectiveness.